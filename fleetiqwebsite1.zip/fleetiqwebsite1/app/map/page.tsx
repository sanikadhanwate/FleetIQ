import { FleetMapView } from "@/components/fleet-map-view"

export default function MapPage() {
  return <FleetMapView />
}
