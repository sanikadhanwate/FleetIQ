import { FleetDashboard } from "@/components/fleet-dashboard"

export default function Page() {
  return <FleetDashboard />
}
