# FleetIQ Backend Integration Guide

This guide explains how to connect your existing backend to the FleetIQ frontend.

## Overview

The FleetIQ dashboard expects vehicle data with the following structure matching your Kaggle dataset:

\`\`\`typescript
interface BackendVehicle {
  // Basic identification
  vehicle_id: string
  vehicle_name: string
  latitude: number
  longitude: number
  
  // Core predictive maintenance metrics (REQUIRED)
  Component_Health_Score: number  // 0.0 to 1.0
  RUL: number                     // Remaining Useful Life in days
  Failure_Probability: number     // 0.0 to 1.0
  Maintenance_Type?: string
  TTF?: number                    // Time to Failure
  
  // Battery metrics (from dataset)
  SoC: number                     // State of Charge (%)
  SoH: number                     // State of Health (%)
  Battery_Voltage: number
  Battery_Current: number
  Battery_Temperature: number
  Charge_Cycles: number
  
  // Motor metrics (from dataset)
  Motor_Temperature: number
  Motor_Vibration: number
  Motor_Torque: number
  Motor_RPM: number
  
  // Braking system (from dataset)
  Brake_Pad_Wear: number
  Brake_Pressure: number
  Reg_Brake_Efficiency: number
  
  // Tire metrics (from dataset)
  Tire_Pressure: number
  Tire_Temperature: number
  
  // Suspension and load (from dataset)
  Suspension_Load: number
  Load_Weight: number
  
  // Environmental conditions (from dataset)
  Ambient_Temperature: number
  Ambient_Humidity: number
  
  // Vehicle dynamics (from dataset)
  Driving_Speed: number
  Distance_Traveled: number
  Idle_Time: number
  Route_Roughness: number
  
  // Power metrics (from dataset)
  Power_Consumption: number
  
  // Timestamp (from dataset)
  Timestamp: string
  
  // Additional fields for display
  mileage?: number
  last_maintenance?: string
}
\`\`\`

## Health Status Thresholds

The system automatically determines status based on `Component_Health_Score`:

- **Healthy**: ≥ 0.8 (Green)
- **Warning**: 0.5 - 0.8 (Yellow/Orange)
- **Critical**: < 0.5 (Red)

## Integration Steps

### 1. Update API Endpoints

Replace the placeholder URLs in `lib/api.ts` with your actual backend endpoints:

\`\`\`typescript
// Example: Update the base URL
const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000'

export async function fetchVehicles(): Promise<BackendVehicle[]> {
  const response = await fetch(`${API_BASE_URL}/api/vehicles`)
  // ... rest of the code
}
\`\`\`

### 2. Add Environment Variables

Add your backend URL to your Vercel project or `.env.local`:

\`\`\`bash
NEXT_PUBLIC_API_URL=https://your-backend-url.com
\`\`\`

### 3. Switch to Live Data

In `app/page.tsx`, replace the static component with the live version:

\`\`\`tsx
// Before (using sample data)
import { FleetDashboard } from "@/components/fleet-dashboard"
export default function Page() {
  return <FleetDashboard />
}

// After (using backend data)
import { FleetDashboardLive } from "@/components/fleet-dashboard-live"
export default function Page() {
  return <FleetDashboardLive />
}
\`\`\`

### 4. Backend API Requirements

Your backend should provide these endpoints:

#### GET /api/vehicles
Returns array of all vehicles with EXACT dataset column names:

\`\`\`json
{
  "success": true,
  "data": [
    {
      "vehicle_id": "VH-001",
      "vehicle_name": "Fleet Vehicle 001",
      "latitude": 40.7128,
      "longitude": -74.006,
      "Timestamp": "2024-01-15T10:30:00Z",
      "Component_Health_Score": 0.92,
      "RUL": 145,
      "Failure_Probability": 0.08,
      "Maintenance_Type": "Preventive",
      "TTF": 200,
      "SoC": 85.3,
      "SoH": 94.2,
      "Battery_Voltage": 385.2,
      "Battery_Current": 42.5,
      "Battery_Temperature": 32.1,
      "Charge_Cycles": 250,
      "Motor_Temperature": 68.3,
      "Motor_Vibration": 0.12,
      "Motor_Torque": 245.5,
      "Motor_RPM": 3200,
      "Power_Consumption": 45.2,
      "Brake_Pad_Wear": 25.5,
      "Brake_Pressure": 115.3,
      "Reg_Brake_Efficiency": 88.5,
      "Tire_Pressure": 32.5,
      "Tire_Temperature": 42.3,
      "Suspension_Load": 850.5,
      "Load_Weight": 1250,
      "Ambient_Temperature": 25.5,
      "Ambient_Humidity": 65.2,
      "Driving_Speed": 65.5,
      "Distance_Traveled": 15234.5,
      "Idle_Time": 125,
      "Route_Roughness": 2.5,
      "mileage": 15234.5,
      "last_maintenance": "2024-01-01"
    }
  ]
}
\`\`\`

#### GET /api/vehicles/:id
Returns single vehicle by ID:

\`\`\`json
{
  "success": true,
  "data": {
    "vehicle_id": "VH-001",
    "vehicle_name": "Fleet Vehicle 001",
    "latitude": 40.7128,
    "longitude": -74.006,
    "Timestamp": "2024-01-15T10:30:00Z",
    "Component_Health_Score": 0.92,
    "RUL": 145,
    "Failure_Probability": 0.08,
    "Maintenance_Type": "Preventive",
    "TTF": 200,
    "SoC": 85.3,
    "SoH": 94.2,
    "Battery_Voltage": 385.2,
    "Battery_Current": 42.5,
    "Battery_Temperature": 32.1,
    "Charge_Cycles": 250,
    "Motor_Temperature": 68.3,
    "Motor_Vibration": 0.12,
    "Motor_Torque": 245.5,
    "Motor_RPM": 3200,
    "Power_Consumption": 45.2,
    "Brake_Pad_Wear": 25.5,
    "Brake_Pressure": 115.3,
    "Reg_Brake_Efficiency": 88.5,
    "Tire_Pressure": 32.5,
    "Tire_Temperature": 42.3,
    "Suspension_Load": 850.5,
    "Load_Weight": 1250,
    "Ambient_Temperature": 25.5,
    "Ambient_Humidity": 65.2,
    "Driving_Speed": 65.5,
    "Distance_Traveled": 15234.5,
    "Idle_Time": 125,
    "Route_Roughness": 2.5,
    "mileage": 15234.5,
    "last_maintenance": "2024-01-01"
  }
}
\`\`\`

### 5. Kaggle Dataset Mapping (EVIoT-PredictiveMaint)

Your dataset contains these EXACT columns. Map them directly to the API:

**Dataset Columns:**
- `Timestamp` - Time of data collection
- `SoC` - State of Charge (%)
- `SoH` - State of Health (%)
- `Battery_Voltage` - Battery voltage (V)
- `Battery_Current` - Battery current (A)
- `Battery_Temperature` - Battery temperature (°C)
- `Charge_Cycles` - Number of charge cycles
- `Motor_Temperature` - Motor temperature (°C)
- `Motor_Vibration` - Motor vibration level
- `Motor_Torque` - Motor torque (Nm)
- `Motor_RPM` - Motor revolutions per minute
- `Power_Consumption` - Power consumption (kW)
- `Brake_Pad_Wear` - Brake pad wear percentage
- `Brake_Pressure` - Brake pressure (bar)
- `Reg_Brake_Efficiency` - Regenerative braking efficiency (%)
- `Tire_Pressure` - Tire pressure (PSI)
- `Tire_Temperature` - Tire temperature (°C)
- `Suspension_Load` - Suspension load
- `Ambient_Temperature` - Ambient temperature (°C)
- `Ambient_Humidity` - Ambient humidity (%)
- `Load_Weight` - Load weight (kg)
- `Driving_Speed` - Driving speed (km/h)
- `Distance_Traveled` - Distance traveled (km)
- `Idle_Time` - Idle time
- `Route_Roughness` - Route roughness index
- `RUL` - Remaining Useful Life (days)
- `Failure_Probability` - Failure probability (0-1)
- `Maintenance_Type` - Type of maintenance needed
- `TTF` - Time to Failure
- `Component_Health_Score` - Component health score (0-1)

**Required Additional Fields (add to your data):**
- `vehicle_id` - Unique identifier for each vehicle
- `vehicle_name` - Display name for the vehicle
- `latitude` - GPS latitude coordinate
- `longitude` - GPS longitude coordinate

**Python Backend Example:**
\`\`\`python
def transform_vehicle_data(dataset_row):
    return {
        # Add identification and location
        "vehicle_id": dataset_row.get("vehicle_id", f"VEH-{dataset_row.name}"),
        "vehicle_name": dataset_row.get("vehicle_name", f"Fleet Vehicle {dataset_row.name}"),
        "latitude": dataset_row.get("latitude", 40.7128),  # Add your GPS data
        "longitude": dataset_row.get("longitude", -74.0060),
        
        # Use EXACT column names from dataset
        "Timestamp": dataset_row["Timestamp"],
        "Component_Health_Score": float(dataset_row["Component_Health_Score"]),
        "RUL": int(dataset_row["RUL"]),
        "Failure_Probability": float(dataset_row["Failure_Probability"]),
        "Maintenance_Type": dataset_row.get("Maintenance_Type"),
        "TTF": dataset_row.get("TTF"),
        
        # Battery
        "SoC": float(dataset_row["SoC"]),
        "SoH": float(dataset_row["SoH"]),
        "Battery_Voltage": float(dataset_row["Battery_Voltage"]),
        "Battery_Current": float(dataset_row["Battery_Current"]),
        "Battery_Temperature": float(dataset_row["Battery_Temperature"]),
        "Charge_Cycles": int(dataset_row["Charge_Cycles"]),
        
        # Motor
        "Motor_Temperature": float(dataset_row["Motor_Temperature"]),
        "Motor_Vibration": float(dataset_row["Motor_Vibration"]),
        "Motor_Torque": float(dataset_row["Motor_Torque"]),
        "Motor_RPM": float(dataset_row["Motor_RPM"]),
        
        # Brakes
        "Brake_Pad_Wear": float(dataset_row["Brake_Pad_Wear"]),
        "Brake_Pressure": float(dataset_row["Brake_Pressure"]),
        "Reg_Brake_Efficiency": float(dataset_row["Reg_Brake_Efficiency"]),
        
        # Tires
        "Tire_Pressure": float(dataset_row["Tire_Pressure"]),
        "Tire_Temperature": float(dataset_row["Tire_Temperature"]),
        
        # Load and environment
        "Suspension_Load": float(dataset_row["Suspension_Load"]),
        "Load_Weight": float(dataset_row["Load_Weight"]),
        "Ambient_Temperature": float(dataset_row["Ambient_Temperature"]),
        "Ambient_Humidity": float(dataset_row["Ambient_Humidity"]),
        
        # Dynamics
        "Driving_Speed": float(dataset_row["Driving_Speed"]),
        "Distance_Traveled": float(dataset_row["Distance_Traveled"]),
        "Idle_Time": float(dataset_row["Idle_Time"]),
        "Route_Roughness": float(dataset_row["Route_Roughness"]),
        "Power_Consumption": float(dataset_row["Power_Consumption"]),
        
        # Optional display fields
        "mileage": float(dataset_row["Distance_Traveled"]),
        "last_maintenance": dataset_row.get("last_maintenance", dataset_row["Timestamp"])
    }
\`\`\`

**Node.js/Express Example:**
\`\`\`javascript
function transformVehicleData(row) {
  return {
    // Add identification and location
    vehicle_id: row.vehicle_id || `VEH-${row.index}`,
    vehicle_name: row.vehicle_name || `Fleet Vehicle ${row.index}`,
    latitude: parseFloat(row.latitude || 40.7128),
    longitude: parseFloat(row.longitude || -74.0060),
    
    // Use EXACT column names from dataset
    Timestamp: row.Timestamp,
    Component_Health_Score: parseFloat(row.Component_Health_Score),
    RUL: parseInt(row.RUL),
    Failure_Probability: parseFloat(row.Failure_Probability),
    Maintenance_Type: row.Maintenance_Type,
    TTF: row.TTF ? parseInt(row.TTF) : undefined,
    
    // Battery
    SoC: parseFloat(row.SoC),
    SoH: parseFloat(row.SoH),
    Battery_Voltage: parseFloat(row.Battery_Voltage),
    Battery_Current: parseFloat(row.Battery_Current),
    Battery_Temperature: parseFloat(row.Battery_Temperature),
    Charge_Cycles: parseInt(row.Charge_Cycles),
    
    // Motor
    Motor_Temperature: parseFloat(row.Motor_Temperature),
    Motor_Vibration: parseFloat(row.Motor_Vibration),
    Motor_Torque: parseFloat(row.Motor_Torque),
    Motor_RPM: parseFloat(row.Motor_RPM),
    
    // Brakes
    Brake_Pad_Wear: parseFloat(row.Brake_Pad_Wear),
    Brake_Pressure: parseFloat(row.Brake_Pressure),
    Reg_Brake_Efficiency: parseFloat(row.Reg_Brake_Efficiency),
    
    // Tires
    Tire_Pressure: parseFloat(row.Tire_Pressure),
    Tire_Temperature: parseFloat(row.Tire_Temperature),
    
    // Load and environment
    Suspension_Load: parseFloat(row.Suspension_Load),
    Load_Weight: parseFloat(row.Load_Weight),
    Ambient_Temperature: parseFloat(row.Ambient_Temperature),
    Ambient_Humidity: parseFloat(row.Ambient_Humidity),
    
    // Dynamics
    Driving_Speed: parseFloat(row.Driving_Speed),
    Distance_Traveled: parseFloat(row.Distance_Traveled),
    Idle_Time: parseFloat(row.Idle_Time),
    Route_Roughness: parseFloat(row.Route_Roughness),
    Power_Consumption: parseFloat(row.Power_Consumption),
    
    // Optional display fields
    mileage: parseFloat(row.Distance_Traveled),
    last_maintenance: row.last_maintenance || row.Timestamp
  };
}
\`\`\`

## Testing

1. Start with the static demo data to verify the UI works
2. Test your API endpoints with curl or Postman
3. Update the frontend to use live data
4. Monitor the browser console for any errors

## Real-time Updates

The dashboard auto-refreshes every 30 seconds. To adjust:

\`\`\`tsx
// In fleet-dashboard-live.tsx
const interval = setInterval(loadVehicles, 60000) // 60 seconds
\`\`\`

## Error Handling

The dashboard includes built-in error handling. Customize the error messages in `lib/api.ts` based on your needs.

## Map Page Integration

The FleetIQ application now includes a dedicated full-screen map view at `/map`.

### Features:
- **Interactive markers**: Click any vehicle to see detailed information
- **Color-coded status**: Green (Healthy ≥0.8), Yellow (Warning 0.5-0.8), Red (Critical <0.5)
- **Legend**: Visual guide for health status thresholds
- **Comprehensive details**: Shows all battery, motor, temperature, and diagnostic data
- **Real-time updates**: Auto-refreshes with latest vehicle data

### Integration:
The map page uses the same API endpoints as the dashboard. Simply ensure your backend returns all the extended fields for the best experience.

## Need Help?

- Check browser console for API errors
- Verify CORS settings on your backend
- Ensure environment variables are set correctly
- Test API endpoints independently before integration
