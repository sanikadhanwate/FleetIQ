import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Activity,
  Battery,
  Calendar,
  Gauge,
  MapPin,
  Zap,
  Wind,
  AlertTriangle,
  CircleGauge,
  DollarSign,
  Wrench,
} from "lucide-react"
import type { Vehicle } from "@/components/fleet-dashboard"
import { cn } from "@/lib/utils"

interface VehicleDetailsProps {
  vehicle: Vehicle
}

export function VehicleDetails({ vehicle }: VehicleDetailsProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "healthy":
        return "bg-success text-success-foreground"
      case "warning":
        return "bg-warning text-warning-foreground"
      case "critical":
        return "bg-destructive text-destructive-foreground"
      default:
        return "bg-secondary text-secondary-foreground"
    }
  }

  const getHealthColor = (score: number) => {
    if (score >= 0.8) return "text-success"
    if (score >= 0.5) return "text-warning"
    return "text-destructive"
  }

  const getProgressColor = (score: number) => {
    if (score >= 0.8) return "bg-success"
    if (score >= 0.5) return "bg-warning"
    return "bg-destructive"
  }

  const healthPercentage = vehicle.component_health_score * 100

  return (
    <Card className="p-6">
      <div className="mb-6 flex items-start justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground">{vehicle.name}</h2>
          <p className="text-sm text-muted-foreground">Vehicle ID: {vehicle.id}</p>
        </div>
        <Badge className={cn("text-sm", getStatusColor(vehicle.status))}>{vehicle.status.toUpperCase()}</Badge>
      </div>

      <div className="space-y-6">
        {/* Component Health Score */}
        <div>
          <div className="mb-2 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Gauge className="h-5 w-5 text-muted-foreground" />
              <span className="font-semibold text-foreground">Component Health Score</span>
            </div>
            <span className={cn("text-2xl font-bold", getHealthColor(vehicle.component_health_score))}>
              {vehicle.component_health_score.toFixed(2)}
            </span>
          </div>
          <Progress value={healthPercentage} className="h-3">
            <div
              className={cn("h-full transition-all", getProgressColor(vehicle.component_health_score))}
              style={{ width: `${healthPercentage}%` }}
            />
          </Progress>
          <div className="mt-2 flex justify-between text-xs text-muted-foreground">
            <span>Critical {"(<0.5)"}</span>
            <span>Warning (0.5-0.8)</span>
            <span>Healthy {"(≥0.8)"}</span>
          </div>
        </div>

        {/* Maintenance Issue and Cost Section */}
        {(vehicle.maintenance_issue || vehicle.estimated_cost) && (
          <div className="rounded-lg border border-warning/30 bg-warning/10 p-4">
            <h3 className="mb-3 flex items-center gap-2 text-lg font-semibold text-foreground">
              <Wrench className="h-5 w-5 text-warning" />
              Maintenance Required
            </h3>
            {vehicle.maintenance_issue && (
              <div className="mb-3 rounded-md bg-background/60 p-3">
                <p className="text-sm font-medium text-muted-foreground mb-1">Issue Description:</p>
                <p className="text-foreground">{vehicle.maintenance_issue}</p>
              </div>
            )}
            {vehicle.estimated_cost && (
              <div className="flex items-center justify-between rounded-md bg-background/60 p-3">
                <div className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5 text-warning" />
                  <span className="font-semibold text-foreground">Estimated Maintenance Cost</span>
                </div>
                <span className="text-2xl font-bold text-warning">${vehicle.estimated_cost.toFixed(2)}</span>
              </div>
            )}
          </div>
        )}

        {/* RUL and Failure Probability */}
        <div className="grid gap-4 md:grid-cols-2">
          <div className="rounded-lg border border-border bg-muted/30 p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Activity className="h-5 w-5 text-primary" />
                <span className="font-semibold text-foreground">RUL</span>
              </div>
              <div className="text-right">
                <div className="text-3xl font-bold text-primary">{vehicle.rul}</div>
                <div className="text-sm text-muted-foreground">days</div>
              </div>
            </div>
          </div>

          {vehicle.Failure_Probability !== undefined && (
            <div className="rounded-lg border border-border bg-muted/30 p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-warning" />
                  <span className="font-semibold text-foreground">Failure Risk</span>
                </div>
                <div className="text-right">
                  <div className="text-3xl font-bold text-warning">
                    {(vehicle.Failure_Probability * 100).toFixed(1)}
                  </div>
                  <div className="text-sm text-muted-foreground">%</div>
                </div>
              </div>
            </div>
          )}
        </div>

        {vehicle.SoC !== undefined && (
          <div className="rounded-lg border border-primary/20 bg-primary/5 p-4">
            <h3 className="mb-3 flex items-center gap-2 text-lg font-semibold text-foreground">
              <Battery className="h-5 w-5" />
              Battery System
            </h3>
            <div className="grid gap-3 md:grid-cols-3">
              <div>
                <p className="text-xs text-muted-foreground">State of Charge</p>
                <p className="text-2xl font-bold text-foreground">{vehicle.SoC?.toFixed(1)}%</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">State of Health</p>
                <p className="text-2xl font-bold text-foreground">{vehicle.SoH?.toFixed(1)}%</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Charge Cycles</p>
                <p className="text-2xl font-bold text-foreground">{vehicle.Charge_Cycles}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Voltage</p>
                <p className="font-semibold text-foreground">{vehicle.Battery_Voltage?.toFixed(1)} V</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Current</p>
                <p className="font-semibold text-foreground">{vehicle.Battery_Current?.toFixed(1)} A</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Temperature</p>
                <p className="font-semibold text-foreground">{vehicle.Battery_Temperature?.toFixed(1)}°C</p>
              </div>
            </div>
          </div>
        )}

        {vehicle.Motor_Temperature !== undefined && (
          <div className="rounded-lg border border-border bg-card p-4">
            <h3 className="mb-3 flex items-center gap-2 text-lg font-semibold text-foreground">
              <Zap className="h-5 w-5" />
              Motor System
            </h3>
            <div className="grid gap-3 md:grid-cols-4">
              <div>
                <p className="text-xs text-muted-foreground">Temperature</p>
                <p className="font-semibold text-foreground">{vehicle.Motor_Temperature?.toFixed(1)}°C</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">RPM</p>
                <p className="font-semibold text-foreground">{vehicle.Motor_RPM?.toFixed(0)}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Torque</p>
                <p className="font-semibold text-foreground">{vehicle.Motor_Torque?.toFixed(1)} Nm</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Vibration</p>
                <p className="font-semibold text-foreground">{vehicle.Motor_Vibration?.toFixed(2)}</p>
              </div>
            </div>
          </div>
        )}

        {vehicle.Brake_Pad_Wear !== undefined && (
          <div className="rounded-lg border border-border bg-card p-4">
            <h3 className="mb-3 flex items-center gap-2 text-lg font-semibold text-foreground">
              <CircleGauge className="h-5 w-5" />
              Braking System
            </h3>
            <div className="grid gap-3 md:grid-cols-3">
              <div>
                <p className="text-xs text-muted-foreground">Pad Wear</p>
                <p className="font-semibold text-foreground">{vehicle.Brake_Pad_Wear?.toFixed(1)}%</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Pressure</p>
                <p className="font-semibold text-foreground">{vehicle.Brake_Pressure?.toFixed(1)} bar</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Regen Efficiency</p>
                <p className="font-semibold text-foreground">{vehicle.Reg_Brake_Efficiency?.toFixed(1)}%</p>
              </div>
            </div>
          </div>
        )}

        <div className="grid gap-4 md:grid-cols-2">
          {vehicle.Tire_Pressure !== undefined && (
            <div className="rounded-lg border border-border bg-card p-4">
              <h3 className="mb-3 flex items-center gap-2 font-semibold text-foreground">
                <Gauge className="h-5 w-5" />
                Tire System
              </h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Pressure</span>
                  <span className="font-semibold">{vehicle.Tire_Pressure?.toFixed(1)} PSI</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Temperature</span>
                  <span className="font-semibold">{vehicle.Tire_Temperature?.toFixed(1)}°C</span>
                </div>
              </div>
            </div>
          )}

          {vehicle.Ambient_Temperature !== undefined && (
            <div className="rounded-lg border border-border bg-card p-4">
              <h3 className="mb-3 flex items-center gap-2 font-semibold text-foreground">
                <Wind className="h-5 w-5" />
                Environment
              </h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Temperature</span>
                  <span className="font-semibold">{vehicle.Ambient_Temperature?.toFixed(1)}°C</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Humidity</span>
                  <span className="font-semibold">{vehicle.Ambient_Humidity?.toFixed(1)}%</span>
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="rounded-lg border border-border bg-card p-4">
          <h3 className="mb-3 flex items-center gap-2 text-lg font-semibold text-foreground">
            <Gauge className="h-5 w-5" />
            Vehicle Dynamics
          </h3>
          <div className="grid gap-3 md:grid-cols-4">
            <div>
              <p className="text-xs text-muted-foreground">Speed</p>
              <p className="font-semibold text-foreground">{vehicle.Driving_Speed?.toFixed(1)} km/h</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Distance</p>
              <p className="font-semibold text-foreground">{vehicle.Distance_Traveled?.toFixed(1)} km</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Load Weight</p>
              <p className="font-semibold text-foreground">{vehicle.Load_Weight?.toFixed(0)} kg</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Power Usage</p>
              <p className="font-semibold text-foreground">{vehicle.Power_Consumption?.toFixed(1)} kW</p>
            </div>
          </div>
        </div>

        {/* Location and Maintenance */}
        <div className="grid gap-4 md:grid-cols-2">
          <div className="flex items-center gap-3 rounded-lg border border-border bg-card p-4">
            <MapPin className="h-5 w-5 text-muted-foreground" />
            <div>
              <p className="text-xs text-muted-foreground">Location</p>
              <p className="font-semibold text-foreground">
                {vehicle.lat.toFixed(4)}, {vehicle.lng.toFixed(4)}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 rounded-lg border border-border bg-card p-4">
            <Calendar className="h-5 w-5 text-muted-foreground" />
            <div>
              <p className="text-xs text-muted-foreground">Last Update</p>
              <p className="font-semibold text-foreground">
                {vehicle.Timestamp ? new Date(vehicle.Timestamp).toLocaleString() : "N/A"}
              </p>
            </div>
          </div>
        </div>
      </div>
    </Card>
  )
}
