"use client"

import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { ChevronRight, Gauge } from "lucide-react"
import type { Vehicle } from "@/components/fleet-dashboard"
import { cn } from "@/lib/utils"

interface VehicleListProps {
  vehicles: Vehicle[]
  selectedVehicle: Vehicle | null
  onSelectVehicle: (vehicle: Vehicle) => void
}

export function VehicleList({ vehicles, selectedVehicle, onSelectVehicle }: VehicleListProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "healthy":
        return "bg-success text-success-foreground"
      case "warning":
        return "bg-warning text-warning-foreground"
      case "critical":
        return "bg-destructive text-destructive-foreground"
      default:
        return "bg-secondary text-secondary-foreground"
    }
  }

  const getHealthColor = (score: number) => {
    if (score >= 0.8) return "text-success"
    if (score >= 0.5) return "text-warning"
    return "text-destructive"
  }

  return (
    <Card className="p-4">
      <h2 className="mb-4 text-lg font-semibold text-foreground">Vehicle Fleet</h2>
      <ScrollArea className="h-[400px]">
        <div className="space-y-2">
          {vehicles.map((vehicle) => (
            <button
              key={vehicle.id}
              onClick={() => onSelectVehicle(vehicle)}
              className={cn(
                "w-full rounded-lg border p-3 text-left transition-all hover:bg-accent/50",
                selectedVehicle?.id === vehicle.id ? "border-primary bg-primary/5" : "border-border bg-card",
              )}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="mb-2 flex items-center justify-between">
                    <h3 className="font-semibold text-foreground">{vehicle.name}</h3>
                    <ChevronRight className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <div className="mb-2 flex items-center gap-2">
                    <Badge variant="secondary" className={cn("text-xs", getStatusColor(vehicle.status))}>
                      {vehicle.status.toUpperCase()}
                    </Badge>
                    <span className="text-xs text-muted-foreground">{vehicle.id}</span>
                  </div>
                  <div className="flex items-center gap-4 text-sm">
                    <div className="flex items-center gap-1">
                      <Gauge className="h-3 w-3 text-muted-foreground" />
                      <span className="text-muted-foreground">Health:</span>
                      <span className={cn("font-semibold", getHealthColor(vehicle.component_health_score))}>
                        {vehicle.component_health_score.toFixed(2)}
                      </span>
                    </div>
                    <div className="flex items-center gap-1">
                      <span className="text-muted-foreground">RUL:</span>
                      <span className="font-semibold text-foreground">{vehicle.rul}d</span>
                    </div>
                  </div>
                </div>
              </div>
            </button>
          ))}
        </div>
      </ScrollArea>
    </Card>
  )
}
