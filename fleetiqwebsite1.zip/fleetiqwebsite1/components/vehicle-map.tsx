"use client"

import { useEffect, useRef } from "react"
import { Card } from "@/components/ui/card"
import type { Vehicle } from "@/components/fleet-dashboard"

interface VehicleMapProps {
  vehicles: Vehicle[]
  selectedVehicle: Vehicle | null
  onSelectVehicle: (vehicle: Vehicle) => void
}

export function VehicleMap({ vehicles, selectedVehicle, onSelectVehicle }: VehicleMapProps) {
  const mapRef = useRef<HTMLDivElement>(null)
  const mapInstanceRef = useRef<any>(null)
  const markersRef = useRef<any[]>([])

  useEffect(() => {
    if (typeof window === "undefined") return

    const initMap = async () => {
      // @ts-ignore - Leaflet loaded via CDN
      const L = window.L
      if (!L || !mapRef.current) return

      // Initialize map
      if (!mapInstanceRef.current) {
        mapInstanceRef.current = L.map(mapRef.current).setView([37.7749, -122.4194], 13)

        L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
          attribution: "© OpenStreetMap contributors",
          maxZoom: 19,
        }).addTo(mapInstanceRef.current)
      }

      // Clear existing markers
      markersRef.current.forEach((marker) => marker.remove())
      markersRef.current = []

      // Add markers for vehicles
      vehicles.forEach((vehicle) => {
        const getMarkerColor = (status: string) => {
          switch (status) {
            case "healthy":
              return "#10b981"
            case "warning":
              return "#f59e0b"
            case "critical":
              return "#ef4444"
            default:
              return "#6366f1"
          }
        }

        const markerIcon = L.divIcon({
          html: `
            <div style="
              width: 32px;
              height: 32px;
              background-color: ${getMarkerColor(vehicle.status)};
              border: 3px solid white;
              border-radius: 50%;
              box-shadow: 0 2px 8px rgba(0,0,0,0.3);
              display: flex;
              align-items: center;
              justify-content: center;
              cursor: pointer;
              ${selectedVehicle?.id === vehicle.id ? "transform: scale(1.3); z-index: 1000;" : ""}
            ">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M14 18V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v11a1 1 0 0 0 1 1h2"/>
                <path d="M15 18H9"/>
                <path d="M19 18h2a1 1 0 0 0 1-1v-3.65a1 1 0 0 0-.22-.624l-3.48-4.35A1 1 0 0 0 17.52 8H14"/>
                <circle cx="17" cy="18" r="2"/>
                <circle cx="7" cy="18" r="2"/>
              </svg>
            </div>
          `,
          className: "",
          iconSize: [32, 32],
          iconAnchor: [16, 16],
        })

        const marker = L.marker([vehicle.lat, vehicle.lng], { icon: markerIcon })
          .addTo(mapInstanceRef.current)
          .bindPopup(`
            <div style="padding: 8px; min-width: 200px;">
              <div style="font-weight: 600; margin-bottom: 8px; font-size: 14px;">${vehicle.name}</div>
              <div style="margin-bottom: 4px; font-size: 12px;">
                <span style="color: #666;">Health Score:</span>
                <span style="font-weight: 600; margin-left: 4px; color: ${getMarkerColor(vehicle.status)};">
                  ${vehicle.component_health_score.toFixed(2)}
                </span>
              </div>
              <div style="margin-bottom: 4px; font-size: 12px;">
                <span style="color: #666;">RUL:</span>
                <span style="font-weight: 600; margin-left: 4px;">${vehicle.rul} days</span>
              </div>
              <div style="margin-bottom: 4px; font-size: 12px;">
                <span style="color: #666;">Status:</span>
                <span style="font-weight: 600; margin-left: 4px; text-transform: uppercase;">${vehicle.status}</span>
              </div>
            </div>
          `)
          .on("click", () => {
            onSelectVehicle(vehicle)
          })

        markersRef.current.push(marker)
      })

      // Center on selected vehicle
      if (selectedVehicle) {
        mapInstanceRef.current.setView([selectedVehicle.lat, selectedVehicle.lng], 15)
      }
    }

    // Load Leaflet CSS and JS
    if (!document.getElementById("leaflet-css")) {
      const link = document.createElement("link")
      link.id = "leaflet-css"
      link.rel = "stylesheet"
      link.href = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
      document.head.appendChild(link)
    }

    if (!document.getElementById("leaflet-js")) {
      const script = document.createElement("script")
      script.id = "leaflet-js"
      script.src = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"
      script.onload = initMap
      document.head.appendChild(script)
    } else {
      initMap()
    }

    return () => {
      markersRef.current.forEach((marker) => marker.remove())
      markersRef.current = []
    }
  }, [vehicles, selectedVehicle, onSelectVehicle])

  return (
    <Card className="overflow-hidden p-0">
      <div className="border-b border-border bg-card p-4">
        <h2 className="text-lg font-semibold text-foreground">Fleet Map</h2>
        <p className="text-sm text-muted-foreground">Real-time vehicle locations</p>
      </div>
      <div ref={mapRef} className="h-[500px] w-full" />
    </Card>
  )
}
