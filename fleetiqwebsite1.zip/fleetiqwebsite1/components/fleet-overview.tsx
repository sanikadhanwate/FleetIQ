import { Card } from "@/components/ui/card"
import { Activity, AlertTriangle, CheckCircle2, TrendingUp } from "lucide-react"
import type { Vehicle } from "@/components/fleet-dashboard"

interface FleetOverviewProps {
  vehicles: Vehicle[]
}

export function FleetOverview({ vehicles }: FleetOverviewProps) {
  const totalVehicles = vehicles.length
  const healthyCount = vehicles.filter((v) => v.status === "healthy").length
  const warningCount = vehicles.filter((v) => v.status === "warning").length
  const criticalCount = vehicles.filter((v) => v.status === "critical").length
  const avgHealthScore = (vehicles.reduce((sum, v) => sum + v.component_health_score, 0) / totalVehicles).toFixed(2)

  const stats = [
    {
      label: "Total Vehicles",
      value: totalVehicles,
      icon: Activity,
      color: "text-primary",
      bgColor: "bg-primary/10",
    },
    {
      label: "Healthy",
      value: healthyCount,
      icon: CheckCircle2,
      color: "text-success",
      bgColor: "bg-success/10",
    },
    {
      label: "Warning",
      value: warningCount,
      icon: AlertTriangle,
      color: "text-warning",
      bgColor: "bg-warning/10",
    },
    {
      label: "Critical",
      value: criticalCount,
      icon: AlertTriangle,
      color: "text-destructive",
      bgColor: "bg-destructive/10",
    },
  ]

  return (
    <Card className="p-4">
      <div className="mb-4 flex items-center justify-between">
        <h2 className="text-lg font-semibold text-foreground">Fleet Overview</h2>
        <div className="flex items-center gap-2 text-sm">
          <TrendingUp className="h-4 w-4 text-muted-foreground" />
          <span className="text-muted-foreground">Avg Health:</span>
          <span className="font-semibold text-foreground">{avgHealthScore}</span>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        {stats.map((stat) => {
          const Icon = stat.icon
          return (
            <div key={stat.label} className="flex items-center gap-3 rounded-lg border border-border bg-card p-3">
              <div className={`flex h-10 w-10 items-center justify-center rounded-lg ${stat.bgColor}`}>
                <Icon className={`h-5 w-5 ${stat.color}`} />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{stat.value}</p>
                <p className="text-xs text-muted-foreground">{stat.label}</p>
              </div>
            </div>
          )
        })}
      </div>
    </Card>
  )
}
