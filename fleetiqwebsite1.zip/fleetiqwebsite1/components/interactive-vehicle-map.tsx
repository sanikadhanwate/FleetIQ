"use client"

import { useEffect, useRef } from "react"
import L from "leaflet"
import "leaflet/dist/leaflet.css"
import type { ExtendedVehicle } from "./fleet-map-view"

// Fix for default marker icon in Next.js
delete (L.Icon.Default.prototype as any)._getIconUrl
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png",
  iconUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png",
  shadowUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png",
})

interface InteractiveVehicleMapProps {
  vehicles: ExtendedVehicle[]
  onVehicleClick: (vehicle: ExtendedVehicle) => void
}

export default function InteractiveVehicleMap({ vehicles, onVehicleClick }: InteractiveVehicleMapProps) {
  const mapRef = useRef<L.Map | null>(null)
  const markersRef = useRef<L.Marker[]>([])

  useEffect(() => {
    if (!mapRef.current) {
      // Initialize map centered on Worcester, MA
      const map = L.map("map").setView([42.2626, -71.8023], 12)

      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        maxZoom: 18,
      }).addTo(map)

      mapRef.current = map
    }

    // Clear existing markers
    markersRef.current.forEach((marker) => marker.remove())
    markersRef.current = []

    // Add markers for each vehicle
    vehicles.forEach((vehicle) => {
      const color = vehicle.status === "healthy" ? "#10b981" : vehicle.status === "warning" ? "#f59e0b" : "#ef4444"

      // Create custom colored icon
      const customIcon = L.divIcon({
        className: "custom-marker",
        html: `
          <div style="
            background-color: ${color};
            width: 32px;
            height: 32px;
            border-radius: 50% 50% 50% 0;
            transform: rotate(-45deg);
            border: 3px solid white;
            box-shadow: 0 2px 8px rgba(0,0,0,0.3);
          ">
            <div style="
              transform: rotate(45deg);
              width: 100%;
              height: 100%;
              display: flex;
              align-items: center;
              justify-content: center;
              color: white;
              font-weight: bold;
              font-size: 14px;
            ">
              ${vehicle.component_health_score >= 0.8 ? "✓" : vehicle.component_health_score >= 0.5 ? "!" : "⚠"}
            </div>
          </div>
        `,
        iconSize: [32, 32],
        iconAnchor: [16, 32],
      })

      const marker = L.marker([vehicle.lat, vehicle.lng], { icon: customIcon })
        .addTo(mapRef.current!)
        .bindPopup(
          `
          <div style="min-width: 250px; font-family: system-ui;">
            <strong style="font-size: 16px; color: #111;">${vehicle.name}</strong>
            <div style="margin-top: 8px;">
              <div style="display: flex; justify-content: space-between; margin: 6px 0; padding: 4px 0; border-bottom: 1px solid #eee;">
                <span style="color: #666;">Health Score:</span>
                <strong style="color: ${color}; font-size: 18px;">${vehicle.component_health_score.toFixed(2)}</strong>
              </div>
              <div style="display: flex; justify-content: space-between; margin: 6px 0; padding: 4px 0; border-bottom: 1px solid #eee;">
                <span style="color: #666;">RUL:</span>
                <strong style="color: #111;">${vehicle.rul} days</strong>
              </div>
              <div style="display: flex; justify-content: space-between; margin: 6px 0; padding: 4px 0; border-bottom: 1px solid #eee;">
                <span style="color: #666;">Battery SoC:</span>
                <strong style="color: #111;">${vehicle.SoC?.toFixed(1)}%</strong>
              </div>
              <div style="display: flex; justify-content: space-between; margin: 6px 0; padding: 4px 0; border-bottom: 1px solid #eee;">
                <span style="color: #666;">Battery SoH:</span>
                <strong style="color: #111;">${vehicle.SoH?.toFixed(1)}%</strong>
              </div>
              <div style="display: flex; justify-content: space-between; margin: 6px 0; padding: 4px 0; border-bottom: 1px solid #eee;">
                <span style="color: #666;">Speed:</span>
                <strong style="color: #111;">${vehicle.Driving_Speed?.toFixed(1)} km/h</strong>
              </div>
              <div style="display: flex; justify-content: space-between; margin: 6px 0; padding: 4px 0; border-bottom: 1px solid #eee;">
                <span style="color: #666;">Motor Temp:</span>
                <strong style="color: #111;">${vehicle.Motor_Temperature?.toFixed(1)}°C</strong>
              </div>
              <div style="display: flex; justify-content: space-between; margin: 6px 0; padding: 4px 0;">
                <span style="color: #666;">Status:</span>
                <strong style="color: ${color}; text-transform: uppercase; font-size: 14px;">${vehicle.status}</strong>
              </div>
            </div>
            <div style="margin-top: 8px; padding-top: 8px; border-top: 2px solid #eee; text-align: center; color: #666; font-size: 12px;">
              Click marker for full details
            </div>
          </div>
        `,
          { maxWidth: 300 },
        )
        .on("click", () => {
          onVehicleClick(vehicle)
        })

      markersRef.current.push(marker)
    })

    // Fit bounds to show all markers
    if (vehicles.length > 0) {
      const bounds = L.latLngBounds(vehicles.map((v) => [v.lat, v.lng]))
      mapRef.current!.fitBounds(bounds, { padding: [50, 50] })
    }
  }, [vehicles, onVehicleClick])

  return <div id="map" className="h-full w-full" />
}
