"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { VehicleMap } from "@/components/vehicle-map"
import { FleetOverview } from "@/components/fleet-overview"
import { VehicleList } from "@/components/vehicle-list"
import { VehicleDetails } from "@/components/vehicle-details"
import { Truck, RefreshCw } from "lucide-react"
import { Button } from "@/components/ui/button"
import { fetchVehicles, transformVehicleData } from "@/lib/api"
import type { Vehicle } from "@/components/fleet-dashboard"

export function FleetDashboardLive() {
  const [selectedVehicle, setSelectedVehicle] = useState<Vehicle | null>(null)
  const [vehicles, setVehicles] = useState<Vehicle[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const loadVehicles = async () => {
    try {
      setLoading(true)
      setError(null)
      const backendVehicles = await fetchVehicles()
      const transformedVehicles = backendVehicles.map(transformVehicleData)
      setVehicles(transformedVehicles)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load vehicles")
      console.error("Error loading vehicles:", err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadVehicles()

    // Auto-refresh every 30 seconds
    const interval = setInterval(loadVehicles, 30000)
    return () => clearInterval(interval)
  }, [])

  if (loading && vehicles.length === 0) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="text-center">
          <RefreshCw className="mx-auto h-8 w-8 animate-spin text-primary" />
          <p className="mt-4 text-muted-foreground">Loading fleet data...</p>
        </div>
      </div>
    )
  }

  if (error && vehicles.length === 0) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <Card className="p-6 text-center">
          <p className="text-destructive">{error}</p>
          <Button onClick={loadVehicles} className="mt-4">
            Retry
          </Button>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary">
                <Truck className="h-6 w-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-foreground">FleetIQ</h1>
                <p className="text-sm text-muted-foreground">Predictive Maintenance Platform</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <Button variant="outline" size="sm" onClick={loadVehicles} disabled={loading}>
                <RefreshCw className={`mr-2 h-4 w-4 ${loading ? "animate-spin" : ""}`} />
                Refresh
              </Button>
              <div className="text-sm text-muted-foreground">Last updated: {new Date().toLocaleTimeString()}</div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="container mx-auto p-4">
        <div className="grid gap-4 lg:grid-cols-3">
          {/* Left Column - Overview and List */}
          <div className="space-y-4 lg:col-span-1">
            <FleetOverview vehicles={vehicles} />
            <VehicleList vehicles={vehicles} selectedVehicle={selectedVehicle} onSelectVehicle={setSelectedVehicle} />
          </div>

          {/* Right Column - Map and Details */}
          <div className="space-y-4 lg:col-span-2">
            <VehicleMap vehicles={vehicles} selectedVehicle={selectedVehicle} onSelectVehicle={setSelectedVehicle} />
            {selectedVehicle && <VehicleDetails vehicle={selectedVehicle} />}
          </div>
        </div>
      </div>
    </div>
  )
}
