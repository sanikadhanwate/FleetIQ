"use client"

import { useState, useEffect } from "react"
import { VehicleMap } from "@/components/vehicle-map"
import { FleetOverview } from "@/components/fleet-overview"
import { VehicleList } from "@/components/vehicle-list"
import { VehicleDetails } from "@/components/vehicle-details"
import { Truck, Map } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { loadCombinedVehicleData, mapMaintenanceType, type CombinedVehicleData } from "@/lib/csv-parser"

export type HealthStatus = "healthy" | "warning" | "critical"

export interface Vehicle {
  id: string
  name: string
  lat: number
  lng: number
  component_health_score: number
  rul: number
  status: HealthStatus
  mileage: number
  lastMaintenance: string
  estimated_cost?: number
  maintenance_issue?: string
  SoC?: number
  SoH?: number
  Battery_Voltage?: number
  Battery_Current?: number
  Battery_Temperature?: number
  Charge_Cycles?: number
  Motor_Temperature?: number
  Motor_Vibration?: number
  Motor_Torque?: number
  Motor_RPM?: number
  Brake_Pad_Wear?: number
  Brake_Pressure?: number
  Reg_Brake_Efficiency?: number
  Tire_Pressure?: number
  Tire_Temperature?: number
  Suspension_Load?: number
  Load_Weight?: number
  Ambient_Temperature?: number
  Ambient_Humidity?: number
  Driving_Speed?: number
  Distance_Traveled?: number
  Idle_Time?: number
  Route_Roughness?: number
  Power_Consumption?: number
  Failure_Probability?: number
  Maintenance_Type?: string
  TTF?: number
  Timestamp?: string
}

export function FleetDashboard() {
  const [selectedVehicle, setSelectedVehicle] = useState<Vehicle | null>(null)
  const [vehicles, setVehicles] = useState<Vehicle[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    async function loadData() {
      try {
        const csvData = await loadCombinedVehicleData()

        if (csvData.length === 0) {
          console.error("[v0] No CSV data loaded, using fallback data")
          setVehicles(getFallbackVehicles())
          setIsLoading(false)
          return
        }

        const limitedData = csvData.slice(0, 20)

        const mappedVehicles: Vehicle[] = limitedData.map((row, index) => {
          const healthScore = row.Health_score_Predicted !== undefined ? row.Health_score_Predicted : (row.SoH + 3) / 6 // Fallback to normalization

          let status: HealthStatus = "healthy"
          if (healthScore < 0.5) status = "critical"
          else if (healthScore < 0.7) status = "warning"

          const lat = 42.2626 + (Math.random() - 0.5) * 0.1
          const lng = -71.8023 + (Math.random() - 0.5) * 0.1

          return {
            id: row.Vehicle_ID,
            name: `Fleet Vehicle ${row.Vehicle_ID}`,
            lat,
            lng,
            component_health_score: Math.max(0, Math.min(1, healthScore)),
            rul: Math.round(row.RUL_Predicted),
            status,
            mileage: Math.round(40000 + Math.random() * 50000),
            lastMaintenance: new Date(Date.now() - Math.random() * 90 * 24 * 60 * 60 * 1000)
              .toISOString()
              .split("T")[0],
            estimated_cost: Math.round(300 + (1 - healthScore) * 3000),
            maintenance_issue: getMaintenanceIssue(status, row),
            SoC: Math.round(50 + Math.random() * 50),
            SoH: Math.round(healthScore * 100),
            Battery_Voltage: row.Battery_Voltage * 100 + 370, // Denormalize
            Battery_Current: row.Battery_Current * 10 + 40,
            Battery_Temperature: row.Battery_Temperature * 10 + 35,
            Charge_Cycles: Math.round((row.Charge_Cycles + 3) * 200),
            Motor_Temperature: row.Motor_Temperature * 15 + 70,
            Motor_Vibration: Math.abs(row.Motor_Vibration * 0.5),
            Motor_Torque: row.Motor_Torque * 50 + 260,
            Motor_RPM: Math.round(row.Motor_RPM * 500 + 3300),
            Brake_Pad_Wear: Math.abs(row.Brake_Pad_Wear * 30 + 40),
            Brake_Pressure: row.Brake_Pressure * 5 + 43,
            Reg_Brake_Efficiency: row.Reg_Brake_Efficiency * 20 + 75,
            Tire_Pressure: row.Tire_Pressure * 2 + 34,
            Tire_Temperature: row.Tire_Temperature * 5 + 30,
            Suspension_Load: Math.round(row.Suspension_Load * 500 + 1400),
            Load_Weight: Math.round(2500 + Math.random() * 2500),
            Ambient_Temperature: 15 + Math.random() * 10,
            Ambient_Humidity: 50 + Math.random() * 20,
            Driving_Speed: 40 + Math.random() * 30,
            Distance_Traveled: Math.round(40000 + Math.random() * 50000),
            Idle_Time: Math.round(30 + Math.random() * 100),
            Route_Roughness: 0.2 + Math.random() * 0.6,
            Power_Consumption: row.Power_Consumption * 20 + 50,
            Failure_Probability: Math.max(0, Math.min(1, 1 - healthScore)),
            Maintenance_Type: mapMaintenanceType(row.Maintenance_Type),
            TTF: Math.round(row.RUL_Predicted),
            Timestamp: new Date().toISOString(),
          }
        })

        setVehicles(mappedVehicles)
        setIsLoading(false)
      } catch (error) {
        console.error("[v0] Error loading vehicle data:", error)
        setVehicles(getFallbackVehicles())
        setIsLoading(false)
      }
    }

    loadData()
  }, [])

  function getMaintenanceIssue(status: HealthStatus, row: CombinedVehicleData): string {
    if (status === "critical") {
      return `CRITICAL: RUL at ${Math.round(row.RUL_Predicted)} days. Immediate inspection required. Battery SoH: ${row.SoH.toFixed(2)}, Motor vibration elevated.`
    } else if (status === "warning") {
      return `WARNING: RUL predicted at ${Math.round(row.RUL_Predicted)} days. Schedule maintenance soon. Monitor battery temperature and motor performance.`
    }
    return `Vehicle operating normally. RUL: ${Math.round(row.RUL_Predicted)} days. Routine maintenance recommended within maintenance window.`
  }

  function getFallbackVehicles(): Vehicle[] {
    return [
      {
        id: "V001",
        name: "Fleet Truck 001",
        lat: 42.2626,
        lng: -71.8023,
        component_health_score: 0.92,
        rul: 145,
        status: "healthy",
        mileage: 45230,
        lastMaintenance: "2025-11-15",
        estimated_cost: 450.0,
        maintenance_issue: "Routine brake inspection and fluid top-up recommended within next maintenance window",
      },
    ]
  }

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="text-center">
          <div className="mb-4 inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-primary border-r-transparent"></div>
          <p className="text-muted-foreground">Loading vehicle data...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary">
                <Truck className="h-6 w-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-foreground">FleetIQ</h1>
                <p className="text-sm text-muted-foreground">Predictive Maintenance Platform</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <Link href="/map">
                <Button variant="outline" className="gap-2 bg-transparent">
                  <Map className="h-4 w-4" />
                  Full Map View
                </Button>
              </Link>
              <div className="text-sm text-muted-foreground">Last updated: {new Date().toLocaleTimeString()}</div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="container mx-auto p-4">
        <div className="grid gap-4 lg:grid-cols-3">
          {/* Left Column - Overview and List */}
          <div className="space-y-4 lg:col-span-1">
            <FleetOverview vehicles={vehicles} />
            <VehicleList vehicles={vehicles} selectedVehicle={selectedVehicle} onSelectVehicle={setSelectedVehicle} />
          </div>

          {/* Right Column - Map and Details */}
          <div className="space-y-4 lg:col-span-2">
            <VehicleMap vehicles={vehicles} selectedVehicle={selectedVehicle} onSelectVehicle={setSelectedVehicle} />
            {selectedVehicle && <VehicleDetails vehicle={selectedVehicle} />}
          </div>
        </div>
      </div>
    </div>
  )
}
