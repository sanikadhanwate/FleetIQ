"use client"

import { useState } from "react"
import dynamic from "next/dynamic"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Activity, AlertTriangle, AlertCircle } from "lucide-react"
import Link from "next/link"

// Dynamic import to avoid SSR issues with Leaflet
const InteractiveVehicleMap = dynamic(() => import("@/components/interactive-vehicle-map"), {
  ssr: false,
  loading: () => (
    <div className="h-full w-full flex items-center justify-center bg-muted">
      <p className="text-muted-foreground">Loading map...</p>
    </div>
  ),
})

export interface ExtendedVehicle {
  id: string
  name: string
  lat: number
  lng: number
  component_health_score: number
  rul: number
  status: "healthy" | "warning" | "critical"
  mileage: number
  lastMaintenance: string
  estimated_cost?: number
  maintenance_issue?: string
  SoC?: number
  SoH?: number
  Battery_Voltage?: number
  Battery_Current?: number
  Battery_Temperature?: number
  Charge_Cycles?: number
  Motor_Temperature?: number
  Motor_Vibration?: number
  Motor_Torque?: number
  Motor_RPM?: number
  Brake_Pad_Wear?: number
  Brake_Pressure?: number
  Reg_Brake_Efficiency?: number
  Tire_Pressure?: number
  Tire_Temperature?: number
  Driving_Speed?: number
  Power_Consumption?: number
  Failure_Probability?: number
  Timestamp?: string
}

const sampleVehicles: ExtendedVehicle[] = [
  {
    id: "VH-001",
    name: "Fleet Vehicle 001",
    lat: 42.2626,
    lng: -71.8023,
    component_health_score: 0.92,
    rul: 145,
    status: "healthy",
    mileage: 25430,
    lastMaintenance: "2024-11-15",
    estimated_cost: 450.0,
    maintenance_issue: "Routine brake inspection and fluid top-up recommended within next maintenance window",
    SoC: 85.3,
    SoH: 94.2,
    Battery_Voltage: 385.2,
    Battery_Current: 42.5,
    Battery_Temperature: 32.1,
    Charge_Cycles: 342,
    Motor_Temperature: 68.3,
    Motor_Vibration: 0.15,
    Motor_Torque: 285.5,
    Motor_RPM: 3200,
    Brake_Pad_Wear: 22.5,
    Brake_Pressure: 45.2,
    Reg_Brake_Efficiency: 92.8,
    Tire_Pressure: 35.2,
    Tire_Temperature: 28.5,
    Driving_Speed: 55.3,
    Power_Consumption: 48.5,
    Failure_Probability: 0.08,
    Timestamp: new Date().toISOString(),
  },
  {
    id: "VH-002",
    name: "Fleet Vehicle 002",
    lat: 42.2726,
    lng: -71.8123,
    component_health_score: 0.68,
    rul: 62,
    status: "warning",
    mileage: 48920,
    lastMaintenance: "2024-10-22",
    estimated_cost: 1850.0,
    maintenance_issue:
      "Battery thermal management showing elevated temperatures. Battery cooling system requires inspection and potential coolant replacement",
    SoC: 67.5,
    SoH: 82.1,
    Battery_Voltage: 378.5,
    Battery_Current: 38.2,
    Battery_Temperature: 38.5,
    Charge_Cycles: 628,
    Motor_Temperature: 75.2,
    Motor_Vibration: 0.42,
    Motor_Torque: 265.2,
    Motor_RPM: 3450,
    Brake_Pad_Wear: 58.3,
    Brake_Pressure: 42.8,
    Reg_Brake_Efficiency: 78.5,
    Tire_Pressure: 33.8,
    Tire_Temperature: 35.2,
    Driving_Speed: 48.2,
    Power_Consumption: 62.3,
    Failure_Probability: 0.32,
    Timestamp: new Date().toISOString(),
  },
  {
    id: "VH-003",
    name: "Fleet Vehicle 003",
    lat: 42.2526,
    lng: -71.7923,
    component_health_score: 0.42,
    rul: 18,
    status: "critical",
    mileage: 67234,
    lastMaintenance: "2024-09-10",
    estimated_cost: 3250.0,
    maintenance_issue:
      "CRITICAL: Motor bearings showing excessive vibration and high temperature. Immediate inspection required to prevent catastrophic failure. Battery cell degradation detected with significant capacity loss",
    SoC: 54.2,
    SoH: 68.5,
    Battery_Voltage: 365.1,
    Battery_Current: 35.8,
    Battery_Temperature: 45.2,
    Charge_Cycles: 892,
    Motor_Temperature: 82.6,
    Motor_Vibration: 0.85,
    Motor_Torque: 242.8,
    Motor_RPM: 3680,
    Brake_Pad_Wear: 78.5,
    Brake_Pressure: 38.5,
    Reg_Brake_Efficiency: 62.3,
    Tire_Pressure: 32.5,
    Tire_Temperature: 38.8,
    Driving_Speed: 28.5,
    Power_Consumption: 78.5,
    Failure_Probability: 0.68,
    Timestamp: new Date().toISOString(),
  },
  {
    id: "VH-004",
    name: "Fleet Vehicle 004",
    lat: 42.2826,
    lng: -71.8223,
    component_health_score: 0.88,
    rul: 128,
    status: "healthy",
    mileage: 31205,
    lastMaintenance: "2024-11-20",
    estimated_cost: 380.0,
    maintenance_issue:
      "Tire pressure monitoring shows slight decrease. Recommended tire pressure check and adjustment at next scheduled service",
    SoC: 91.2,
    SoH: 96.8,
    Battery_Voltage: 388.7,
    Battery_Current: 44.1,
    Battery_Temperature: 30.5,
    Charge_Cycles: 285,
    Motor_Temperature: 65.8,
    Motor_Vibration: 0.12,
    Motor_Torque: 292.5,
    Motor_RPM: 3150,
    Brake_Pad_Wear: 18.5,
    Brake_Pressure: 46.8,
    Reg_Brake_Efficiency: 94.5,
    Tire_Pressure: 34.2,
    Tire_Temperature: 27.8,
    Driving_Speed: 58.5,
    Power_Consumption: 45.8,
    Failure_Probability: 0.05,
    Timestamp: new Date().toISOString(),
  },
  {
    id: "VH-005",
    name: "Fleet Vehicle 005",
    lat: 42.2426,
    lng: -71.8323,
    component_health_score: 0.55,
    rul: 45,
    status: "warning",
    mileage: 52890,
    lastMaintenance: "2024-10-05",
    estimated_cost: 2100.0,
    maintenance_issue:
      "Battery State of Health declining faster than expected. Battery pack assessment and potential cell replacement needed. Regenerative braking efficiency reduced",
    SoC: 62.8,
    SoH: 78.3,
    Battery_Voltage: 374.2,
    Battery_Current: 36.5,
    Battery_Temperature: 41.8,
    Charge_Cycles: 745,
    Motor_Temperature: 78.4,
    Motor_Vibration: 0.52,
    Motor_Torque: 258.5,
    Motor_RPM: 3520,
    Brake_Pad_Wear: 64.2,
    Brake_Pressure: 41.5,
    Reg_Brake_Efficiency: 72.8,
    Tire_Pressure: 33.5,
    Tire_Temperature: 36.5,
    Driving_Speed: 38.7,
    Power_Consumption: 68.2,
    Failure_Probability: 0.45,
    Timestamp: new Date().toISOString(),
  },
]

export function FleetMapView() {
  const [selectedVehicle, setSelectedVehicle] = useState<ExtendedVehicle | null>(null)

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link href="/">
                <Button variant="ghost" size="icon">
                  <ArrowLeft className="h-5 w-5" />
                </Button>
              </Link>
              <div>
                <h1 className="text-2xl font-bold">Fleet Map</h1>
                <p className="text-sm text-muted-foreground">Real-time vehicle locations and health status</p>
              </div>
            </div>

            {/* Legend */}
            <div className="flex items-center gap-6">
              <div className="flex items-center gap-2">
                <div className="h-3 w-3 rounded-full bg-success" />
                <span className="text-sm">Healthy (≥0.8)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="h-3 w-3 rounded-full bg-warning" />
                <span className="text-sm">Warning (0.5-0.8)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="h-3 w-3 rounded-full bg-destructive" />
                <span className="text-sm">Critical (&lt;0.5)</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Map and Details */}
      <div className="container mx-auto px-4 py-6">
        <div className="grid gap-6 lg:grid-cols-3">
          {/* Map */}
          <div className="lg:col-span-2">
            <Card className="overflow-hidden">
              <div className="h-[calc(100vh-180px)]">
                <InteractiveVehicleMap vehicles={sampleVehicles} onVehicleClick={setSelectedVehicle} />
              </div>
            </Card>
          </div>

          {/* Vehicle Details Panel */}
          <div className="lg:col-span-1">
            <Card className="p-6 h-[calc(100vh-180px)] overflow-y-auto">
              {selectedVehicle ? (
                <div className="space-y-6">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <h2 className="text-xl font-bold">{selectedVehicle.name}</h2>
                      <Badge
                        variant={
                          selectedVehicle.status === "healthy"
                            ? "default"
                            : selectedVehicle.status === "warning"
                              ? "secondary"
                              : "destructive"
                        }
                        className={
                          selectedVehicle.status === "healthy"
                            ? "bg-success hover:bg-success/90"
                            : selectedVehicle.status === "warning"
                              ? "bg-warning hover:bg-warning/90"
                              : ""
                        }
                      >
                        {selectedVehicle.status === "healthy" && <Activity className="mr-1 h-3 w-3" />}
                        {selectedVehicle.status === "warning" && <AlertTriangle className="mr-1 h-3 w-3" />}
                        {selectedVehicle.status === "critical" && <AlertCircle className="mr-1 h-3 w-3" />}
                        {selectedVehicle.status.toUpperCase()}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">{selectedVehicle.id}</p>
                  </div>

                  {/* Health Score */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Component Health Score</span>
                      <span className="text-2xl font-bold">{selectedVehicle.component_health_score.toFixed(2)}</span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div
                        className={`h-full transition-all ${
                          selectedVehicle.status === "healthy"
                            ? "bg-success"
                            : selectedVehicle.status === "warning"
                              ? "bg-warning"
                              : "bg-destructive"
                        }`}
                        style={{ width: `${selectedVehicle.component_health_score * 100}%` }}
                      />
                    </div>
                  </div>

                  {/* RUL */}
                  <div className="space-y-1">
                    <span className="text-sm font-medium">Remaining Useful Life</span>
                    <p className="text-3xl font-bold">{selectedVehicle.rul} days</p>
                  </div>

                  {/* Maintenance Issue */}
                  {selectedVehicle.maintenance_issue && (
                    <div className="space-y-2 border-t pt-4">
                      <h3 className="font-semibold text-sm">Maintenance Required</h3>
                      <p className="text-sm text-muted-foreground leading-relaxed">
                        {selectedVehicle.maintenance_issue}
                      </p>
                      {selectedVehicle.estimated_cost && (
                        <div className="flex items-center justify-between mt-2 p-2 bg-muted/50 rounded">
                          <span className="text-sm font-medium">Estimated Cost:</span>
                          <span className="text-lg font-bold">${selectedVehicle.estimated_cost.toFixed(2)}</span>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Battery Information */}
                  <div className="space-y-3 border-t pt-4">
                    <h3 className="font-semibold">Battery Status</h3>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <p className="text-xs text-muted-foreground">State of Charge</p>
                        <p className="text-lg font-semibold">{selectedVehicle.SoC?.toFixed(1)}%</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-xs text-muted-foreground">State of Health</p>
                        <p className="text-lg font-semibold">{selectedVehicle.SoH?.toFixed(1)}%</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-xs text-muted-foreground">Voltage</p>
                        <p className="text-lg font-semibold">{selectedVehicle.Battery_Voltage?.toFixed(1)}V</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-xs text-muted-foreground">Current</p>
                        <p className="text-lg font-semibold">{selectedVehicle.Battery_Current?.toFixed(1)}A</p>
                      </div>
                    </div>
                  </div>

                  {/* Temperature Information */}
                  <div className="space-y-3 border-t pt-4">
                    <h3 className="font-semibold">Temperature Monitoring</h3>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <p className="text-xs text-muted-foreground">Battery Temp</p>
                        <p className="text-lg font-semibold">{selectedVehicle.Battery_Temperature?.toFixed(1)}°C</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-xs text-muted-foreground">Motor Temp</p>
                        <p className="text-lg font-semibold">{selectedVehicle.Motor_Temperature?.toFixed(1)}°C</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-xs text-muted-foreground">Motor Vibration</p>
                        <p className="text-lg font-semibold">{selectedVehicle.Motor_Vibration?.toFixed(2)}</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-xs text-muted-foreground">Speed</p>
                        <p className="text-lg font-semibold">{selectedVehicle.Driving_Speed?.toFixed(1)} km/h</p>
                      </div>
                    </div>
                  </div>

                  {/* Vehicle Stats */}
                  <div className="space-y-3 border-t pt-4">
                    <h3 className="font-semibold">Vehicle Information</h3>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Mileage</span>
                        <span className="text-sm font-medium">{selectedVehicle.mileage.toLocaleString()} km</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Last Maintenance</span>
                        <span className="text-sm font-medium">{selectedVehicle.lastMaintenance}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Failure Probability</span>
                        <span className="text-sm font-medium">
                          {(selectedVehicle.Failure_Probability! * 100).toFixed(1)}%
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="h-full flex items-center justify-center text-center">
                  <div className="space-y-2">
                    <p className="text-muted-foreground">Click on a vehicle marker to view details</p>
                    <p className="text-sm text-muted-foreground">Showing {sampleVehicles.length} vehicles on the map</p>
                  </div>
                </div>
              )}
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
