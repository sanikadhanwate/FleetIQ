export interface BackendVehicle {
  // Basic identification
  vehicle_id: string
  vehicle_name: string
  latitude: number
  longitude: number

  // Core predictive maintenance metrics
  Component_Health_Score: number
  RUL: number // Remaining Useful Life in days
  Failure_Probability: number
  Maintenance_Type?: string
  TTF?: number // Time to Failure

  estimated_cost?: number // Estimated maintenance cost in USD
  maintenance_issue?: string // Description of the maintenance problem

  // Battery metrics
  SoC: number // State of Charge (%)
  SoH: number // State of Health (%)
  Battery_Voltage: number
  Battery_Current: number
  Battery_Temperature: number
  Charge_Cycles: number

  // Motor metrics
  Motor_Temperature: number
  Motor_Vibration: number
  Motor_Torque: number
  Motor_RPM: number

  // Braking system
  Brake_Pad_Wear: number
  Brake_Pressure: number
  Reg_Brake_Efficiency: number

  // Tire metrics
  Tire_Pressure: number
  Tire_Temperature: number

  // Suspension and load
  Suspension_Load: number
  Load_Weight: number

  // Environmental conditions
  Ambient_Temperature: number
  Ambient_Humidity: number

  // Vehicle dynamics
  Driving_Speed: number
  Distance_Traveled: number
  Idle_Time: number
  Route_Roughness: number

  // Power metrics
  Power_Consumption: number

  // Timestamp
  Timestamp: string

  // Additional fields for display
  mileage?: number
  last_maintenance?: string
}

export interface ApiResponse<T> {
  success: boolean
  data: T
  error?: string
}

/**
 * Fetch all vehicles from your backend
 * Replace with your actual backend URL
 */
export async function fetchVehicles(): Promise<BackendVehicle[]> {
  try {
    const apiUrl = process.env.NEXT_PUBLIC_API_URL || "/api/vehicles"
    const response = await fetch(apiUrl, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    })

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }

    const data: ApiResponse<BackendVehicle[]> = await response.json()

    if (!data.success) {
      throw new Error(data.error || "Failed to fetch vehicles")
    }

    return data.data
  } catch (error) {
    console.error("Error fetching vehicles:", error)
    throw error
  }
}

/**
 * Fetch a single vehicle by ID
 */
export async function fetchVehicleById(vehicleId: string): Promise<BackendVehicle> {
  try {
    const apiUrl = process.env.NEXT_PUBLIC_API_URL || "/api/vehicles"
    const response = await fetch(`${apiUrl}/${vehicleId}`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    })

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }

    const data: ApiResponse<BackendVehicle> = await response.json()

    if (!data.success) {
      throw new Error(data.error || "Failed to fetch vehicle")
    }

    return data.data
  } catch (error) {
    console.error(`Error fetching vehicle ${vehicleId}:`, error)
    throw error
  }
}

/**
 * Helper function to determine health status based on Component_Health_Score
 */
export function getHealthStatus(score: number): "healthy" | "warning" | "critical" {
  if (score >= 0.8) return "healthy"
  if (score >= 0.5) return "warning"
  return "critical"
}

/**
 * Transform backend data to frontend format
 */
export function transformVehicleData(backendVehicle: BackendVehicle) {
  return {
    id: backendVehicle.vehicle_id,
    name: backendVehicle.vehicle_name,
    lat: backendVehicle.latitude,
    lng: backendVehicle.longitude,
    component_health_score: backendVehicle.Component_Health_Score,
    rul: backendVehicle.RUL,
    status: getHealthStatus(backendVehicle.Component_Health_Score),
    mileage: backendVehicle.mileage || backendVehicle.Distance_Traveled,
    lastMaintenance: backendVehicle.last_maintenance || backendVehicle.Timestamp,
    estimated_cost: backendVehicle.estimated_cost,
    maintenance_issue: backendVehicle.maintenance_issue,
    // All dataset features
    SoC: backendVehicle.SoC,
    SoH: backendVehicle.SoH,
    Battery_Voltage: backendVehicle.Battery_Voltage,
    Battery_Current: backendVehicle.Battery_Current,
    Battery_Temperature: backendVehicle.Battery_Temperature,
    Charge_Cycles: backendVehicle.Charge_Cycles,
    Motor_Temperature: backendVehicle.Motor_Temperature,
    Motor_Vibration: backendVehicle.Motor_Vibration,
    Motor_Torque: backendVehicle.Motor_Torque,
    Motor_RPM: backendVehicle.Motor_RPM,
    Brake_Pad_Wear: backendVehicle.Brake_Pad_Wear,
    Brake_Pressure: backendVehicle.Brake_Pressure,
    Reg_Brake_Efficiency: backendVehicle.Reg_Brake_Efficiency,
    Tire_Pressure: backendVehicle.Tire_Pressure,
    Tire_Temperature: backendVehicle.Tire_Temperature,
    Suspension_Load: backendVehicle.Suspension_Load,
    Load_Weight: backendVehicle.Load_Weight,
    Ambient_Temperature: backendVehicle.Ambient_Temperature,
    Ambient_Humidity: backendVehicle.Ambient_Humidity,
    Driving_Speed: backendVehicle.Driving_Speed,
    Distance_Traveled: backendVehicle.Distance_Traveled,
    Idle_Time: backendVehicle.Idle_Time,
    Route_Roughness: backendVehicle.Route_Roughness,
    Power_Consumption: backendVehicle.Power_Consumption,
    Failure_Probability: backendVehicle.Failure_Probability,
    Maintenance_Type: backendVehicle.Maintenance_Type,
    TTF: backendVehicle.TTF,
    Timestamp: backendVehicle.Timestamp,
  }
}
