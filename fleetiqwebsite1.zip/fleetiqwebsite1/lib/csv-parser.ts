export interface VehicleCSVRow {
  Vehicle_ID: string
  SoH: number
  Battery_Voltage: number
  Battery_Current: number
  Battery_Temperature: number
  Charge_Cycles: number
  Motor_Temperature: number
  Motor_Vibration: number
  Motor_Torque: number
  Motor_RPM: number
  Power_Consumption: number
  Brake_Pad_Wear: number
  Brake_Pressure: number
  Reg_Brake_Efficiency: number
  Tire_Pressure: number
  Tire_Temperature: number
  Suspension_Load: number
  RUL: number
  Maintenance_Type: number
  RUL_Predicted: number
  Prediction_Error: number
}

export interface HealthCSVRow {
  Vehicle_ID: string
  SoH: number
  Battery_Voltage: number
  Battery_Current: number
  Battery_Temperature: number
  Charge_Cycles: number
  Motor_Temperature: number
  Motor_Vibration: number
  Motor_Torque: number
  Motor_RPM: number
  Power_Consumption: number
  Brake_Pad_Wear: number
  Brake_Pressure: number
  Reg_Brake_Efficiency: number
  Tire_Pressure: number
  Tire_Temperature: number
  Suspension_Load: number
  Maintenance_Type: number
  Health_score: number
  Health_score_Predicted: number
  Prediction_Error: number
}

export interface CombinedVehicleData extends VehicleCSVRow {
  Health_score?: number
  Health_score_Predicted?: number
  Health_Prediction_Error?: number
}

export function parseCSVLine(line: string): string[] {
  const result: string[] = []
  let current = ""
  let inQuotes = false

  for (let i = 0; i < line.length; i++) {
    const char = line[i]
    if (char === '"') {
      inQuotes = !inQuotes
    } else if (char === "," && !inQuotes) {
      result.push(current.trim())
      current = ""
    } else {
      current += char
    }
  }
  result.push(current.trim())
  return result
}

export async function loadVehicleDataFromCSV(): Promise<VehicleCSVRow[]> {
  try {
    const response = await fetch("/data/EV_RUL_predictions_test_small.csv")
    const text = await response.text()
    const lines = text.split("\n").filter((line) => line.trim())

    if (lines.length === 0) return []

    const headers = parseCSVLine(lines[0])
    const data: VehicleCSVRow[] = []

    for (let i = 1; i < lines.length; i++) {
      const values = parseCSVLine(lines[i])
      if (values.length !== headers.length) continue

      const row: any = {}
      headers.forEach((header, index) => {
        const value = values[index]
        if (header === "Vehicle_ID") {
          row[header] = value
        } else {
          row[header] = Number.parseFloat(value)
        }
      })
      data.push(row as VehicleCSVRow)
    }

    return data
  } catch (error) {
    console.error("[v0] Error loading RUL CSV:", error)
    return []
  }
}

export async function loadHealthDataFromCSV(): Promise<Map<string, HealthCSVRow>> {
  try {
    const response = await fetch("/data/EV_Health_predictions_test_small.csv")
    const text = await response.text()
    const lines = text.split("\n").filter((line) => line.trim())

    if (lines.length === 0) return new Map()

    const headers = parseCSVLine(lines[0])
    const dataMap = new Map<string, HealthCSVRow>()

    for (let i = 1; i < lines.length; i++) {
      const values = parseCSVLine(lines[i])
      if (values.length !== headers.length) continue

      const row: any = {}
      headers.forEach((header, index) => {
        const value = values[index]
        if (header === "Vehicle_ID") {
          row[header] = value
        } else {
          row[header] = Number.parseFloat(value)
        }
      })
      dataMap.set(row.Vehicle_ID, row as HealthCSVRow)
    }

    return dataMap
  } catch (error) {
    console.error("[v0] Error loading Health CSV:", error)
    return new Map()
  }
}

export async function loadCombinedVehicleData(): Promise<CombinedVehicleData[]> {
  try {
    const [rulData, healthMap] = await Promise.all([loadVehicleDataFromCSV(), loadHealthDataFromCSV()])

    const combinedData: CombinedVehicleData[] = rulData.map((rulRow) => {
      const healthRow = healthMap.get(rulRow.Vehicle_ID)

      if (healthRow) {
        return {
          ...rulRow,
          Health_score: healthRow.Health_score,
          Health_score_Predicted: healthRow.Health_score_Predicted,
          Health_Prediction_Error: healthRow.Prediction_Error,
        }
      }

      return rulRow
    })

    return combinedData
  } catch (error) {
    console.error("[v0] Error loading combined vehicle data:", error)
    return []
  }
}

export function mapMaintenanceType(value: number): string {
  // Map the numeric maintenance type to string
  if (value > 2) return "Emergency"
  if (value > 0) return "Corrective"
  if (value > -0.5) return "Preventive"
  return "Routine"
}
